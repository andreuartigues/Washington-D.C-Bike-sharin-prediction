

#Hi Daniel! Make sure that the teminal's PS is set to run in the current folder's path.
# Otherwise wont't work :(
    
#Some teammates had to make sure to do first: cd "path of the folder". example: cd "C:\Users\Daniel\GroupProject"

#Once the above is clear, click the top right "play button" and enjoy :)

import os
if __name__ == "__main__":
    streamlit_app_filename = "💻Homepage.py"
    command = f"streamlit run {streamlit_app_filename}"
    os.system(command)