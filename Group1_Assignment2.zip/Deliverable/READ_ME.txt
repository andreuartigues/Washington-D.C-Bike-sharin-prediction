Hi Daniel, just quick clarification for the additional files in this folder.

1. The landing page for Streamlit is "💻Homepage.py", as we used multipages in the assignment. The rest of the pages are, of course, in the pages folder.

2. "my_streamlit_functions.py" is a collection of functions used adequatly prepared for its later use in streamlit related files. Its just a middle file where to define functions.

That's it :)